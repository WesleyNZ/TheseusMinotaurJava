package nz.ac.wew248.simplethesmin.model;

public enum Wall {
    EMPTY,
    WALL;
}
