package nz.ac.wew248.simplethesmin.model;


public interface IObserver {
    void update();
}
