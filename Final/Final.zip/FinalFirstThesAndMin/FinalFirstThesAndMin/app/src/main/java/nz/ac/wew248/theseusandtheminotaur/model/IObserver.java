package nz.ac.wew248.theseusandtheminotaur.model;


public interface IObserver {
    void update();
}
