package nz.ac.wew248.theseusandtheminotaur.model;

public enum Wall {
    EMPTY,
    WALL;
}
